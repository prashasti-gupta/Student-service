package com.school.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.school.model.Student;
import com.school.repository.StudentRepository;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/students")
public class StudentController {

	@Autowired
	private StudentRepository studentRepo;
	
	@PostMapping("/add")
	public String addStudent(@RequestBody Student st) {
		studentRepo.save(st);
		return "Student added successfully!";
	}
	@GetMapping("/get")
	public List<Student> getAllStudents(){
		return studentRepo.findAll();
	}
	@GetMapping("get/{id}")
	public Optional<Student> getStudentById(@PathVariable Long id) {
		return studentRepo.findById(id);
	}
	@PutMapping("update/{id}")
	public String updateStudent(@PathVariable Long id, @RequestBody Student st) {
		Optional<Student> updSt = studentRepo.findById(id);
		if(updSt.isPresent()) {
			Student existingSt = updSt.get();
			existingSt.setId(st.getId());
			existingSt.setName(st.getName());
			existingSt.setAge(st.getAge());
			return "Student updated successfully!";
		}
		else {
			return "Student with id " + id + " not found!";
		}
	}
	@DeleteMapping("delete/{id}")
	public String deleteStudent(@PathVariable Long id) {
		Optional<Student> updSt = studentRepo.findById(id);
		if(updSt.isPresent()) {
			studentRepo.deleteById(id);
			return "Student deleted successfully!";
		} else {
			return "Student with id " + id + " not found!";
		}
	}
	
}
