package com.school.controller;

import com.school.model.Student;
import com.school.repository.StudentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class StudentControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Mock
    private StudentRepository studentRepo;

    @InjectMocks
    private StudentController studentController;

    private Student student;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        student = new Student(1L, "Alice", 24);
    }

    @Test
    public void testAddStudent() throws Exception {
        when(studentRepo.save(any(Student.class))).thenReturn(student);

        mockMvc.perform(post("/students")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1, \"name\":\"Alice\", \"age\":24}"))
                .andExpect(status().isOk())
                .andExpect(content().string("Student added successfully!"));

        verify(studentRepo, times(1)).save(any(Student.class));
    }

    @Test
    public void testGetAllStudents() throws Exception {
        when(studentRepo.findAll()).thenReturn(Collections.singletonList(student));

        mockMvc.perform(get("/students"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Alice"))
                .andExpect(jsonPath("$[0].age").value(24));

        verify(studentRepo, times(1)).findAll();
    }

    @Test
    public void testGetStudentById() throws Exception {
        when(studentRepo.findById(1L)).thenReturn(Optional.of(student));

        mockMvc.perform(get("/students/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Alice"))
                .andExpect(jsonPath("$.age").value(24));

        verify(studentRepo, times(1)).findById(1L);
    }

    @Test
    public void testUpdateStudent() throws Exception {
        when(studentRepo.findById(1L)).thenReturn(Optional.of(student));
        when(studentRepo.save(any(Student.class))).thenReturn(student);

        mockMvc.perform(put("/students/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1, \"name\":\"Alice Updated\", \"age\":27}"))
                .andExpect(status().isOk())
                .andExpect(content().string("Student updated successfully!"));

        verify(studentRepo, times(1)).save(any(Student.class));
    }

    @Test
    public void testDeleteStudent() throws Exception {
        when(studentRepo.findById(1L)).thenReturn(Optional.of(student));

        mockMvc.perform(delete("/students/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Student deleted successfully!"));

        verify(studentRepo, times(1)).deleteById(1L);
    }

    @Test
    public void testDeleteStudentNotFound() throws Exception {
        when(studentRepo.findById(1L)).thenReturn(Optional.empty());

        mockMvc.perform(delete("/students/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Student with id 1 not found!"));

        verify(studentRepo, times(0)).deleteById(1L);
    }
}
